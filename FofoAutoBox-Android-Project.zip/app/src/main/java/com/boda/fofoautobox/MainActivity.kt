package com.boda.fofoautobox

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "🤖 Fofo Auto Box"
            textSize = 26f
            setPadding(32, 40, 32, 20)
        }
        val info = TextView(this).apply {
            text = "فعّل خدمة إمكانية الوصول، ثم افتح FofoChat.\n\nالبوت يبحث عن عناصر تحمل كلمات مثل: صندوق، مكافأة، صندوق المكافآت، Box، Reward، ويفتح العنصر القابل للنقر.\n\nلن يتجاوز CAPTCHA أو تسجيل الدخول أو أي حماية."
            textSize = 17f
            setPadding(32, 10, 32, 20)
        }
        val open = Button(this).apply {
            text = "⚙️ تفعيل خدمة الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val status = TextView(this).apply {
            text = "الحالة: فعّل الخدمة من إعدادات Android"
            textSize = 16f
            setPadding(32, 20, 32, 20)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(info)
            addView(open)
            addView(status)
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
