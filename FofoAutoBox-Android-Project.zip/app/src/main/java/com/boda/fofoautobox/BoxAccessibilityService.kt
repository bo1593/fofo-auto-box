package com.boda.fofoautobox

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Handler
import android.os.Looper

class BoxAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastClick = 0L
    private val cooldownMs = 1200L

    private val keywords = listOf(
        "صندوق", "صندوق المكافآت", "مكافأة", "المكافآت",
        "box", "reward", "rewards", "gift", "chest"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val root = rootInActiveWindow ?: return
        // Search only visible, clickable nodes. No credential collection or security bypass.
        handler.post { findAndOpen(root) }
    }

    private fun findAndOpen(root: AccessibilityNodeInfo) {
        val now = System.currentTimeMillis()
        if (now - lastClick < cooldownMs) return

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val text = (node.text?.toString() ?: "") + " " + (node.contentDescription?.toString() ?: "")
            if (node.isVisibleToUser && node.isClickable && keywords.any { text.contains(it, ignoreCase = true) }) {
                if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    lastClick = now
                    return
                }
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::addLast)
        }
    }

    override fun onInterrupt() {}
}
